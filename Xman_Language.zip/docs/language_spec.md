# Xman Language Specification

## Commands

- `say "text"` — Print text to the console.
- `remember "fact"` — Store a memory.
- `recall` — Print all remembered items.
- `set mood to happy` — Sets the current mood.
- `if mood is happy then say "Hello"` — Conditional emotion logic.
- `simulate gravity` — Simulate a physics effect.

## Philosophy

Xman is designed for natural reasoning, simulation, and AI-like emotional logic.
