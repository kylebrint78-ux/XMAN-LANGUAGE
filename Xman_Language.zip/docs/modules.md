# Xman Modules

## Emotion
- Track emotional states
- React conditionally

## Memory
- Store facts with `remember`
- Recall them later

## Simulation
- Physical world simulation (e.g. gravity)

## Expression
- Speech with `say`
