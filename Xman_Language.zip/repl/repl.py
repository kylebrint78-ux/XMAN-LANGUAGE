# repl/repl.py

from xman_engine import XmanInterpreter

def start_repl():
    interpreter = XmanInterpreter()
    print("Xman REPL started. Type 'exit' to quit.")
    while True:
        try:
            line = input(">> ")
            if line.lower() == "exit":
                break
            interpreter.process(line.strip())
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    start_repl()
