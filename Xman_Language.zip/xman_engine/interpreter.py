# xman_engine/interpreter.py

class XmanInterpreter:
    def __init__(self):
        self.memory = []
        self.mood = None

    def run(self, code):
        for line in code.strip().split("\n"):
            self.process(line.strip())

    def process(self, line):
        if not line or line.startswith("#"):
            return
        if line.startswith("say "):
            print(line[4:].strip('" '))
        elif line.startswith("remember "):
            self.memory.append(line[9:].strip('" '))
        elif line.startswith("recall"):
            for m in self.memory:
                print(f"(Memory) {m}")
        elif line.startswith("set mood to "):
            self.mood = line.replace("set mood to", "").strip()
            print(f"(Mood set to {self.mood})")
        elif line.startswith("if mood is "):
            parts = line.split("then")
            mood_check = parts[0].replace("if mood is", "").strip()
            action = parts[1].strip() if len(parts) > 1 else ""
            if self.mood == mood_check:
                self.process(action)
        elif line.startswith("simulate gravity"):
            print("Simulating gravity... (Earth standard 9.8 m/s^2)")
        else:
            print(f"Unknown command: {line}")
